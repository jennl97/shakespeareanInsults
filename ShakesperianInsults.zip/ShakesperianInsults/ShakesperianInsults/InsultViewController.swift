//
//  InsultViewController.swift
//  ShakesperianInsults
//
//  Created by student on 3/1/17.
//  Copyright © 2017 jhott-leitsch. All rights reserved.
//

import UIKit

class InsultViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var insultPicker: UIPickerView!
    private let insultOne = 0
    private let insultTwo = 1
    private let insultOneTypes = ["Idle Headed", "Ill Breeding", "Knotty Pated", "Milk Livered", "Onion Eyed", "Pox Marked", "Rump Fed"]
    private let insultTwoTypes = ["lewdster", "lout", "maggot pie", "measle", "nut hook", "pignut", "puttock"]
    
    @IBAction func onButtonPresses(_ sender: UIButton) {
        let insultOneRow = insultPicker.selectedRow(inComponent: insultOne)
        let insultTwoRow = insultPicker.selectedRow(inComponent: insultTwo)
        let oneInsult = insultOneTypes[insultOneRow]
        let twoInsult = insultTwoTypes[insultTwoRow]
        
        let message = "Thou ist a \(oneInsult) \(twoInsult)"
        
        let alert = UIAlertController(
            title: "God save the Queen!",
            message: message,
            preferredStyle: .alert)
        
        let action = UIAlertAction(
            title: "Good day, SIR!",
            style: .default,
            handler: nil)
        
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    //MARK:-
    //MARK: Picker Data Source Methods
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == insultTwo{
            return insultTwoTypes.count} else {
            return insultOneTypes.count}
    }
    
    //MARK:-
    //MARK: Picker Delegate Methods
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == insultTwo {
            return insultTwoTypes[row]}
        else {
            return insultOneTypes[row]}
}
}
